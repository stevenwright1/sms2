// start.js
// Copyright (c) 2008 - 2010 Citrix Systems, Inc. All rights reserved.

function onLoadLayout() {
    detectEnvironment();
}
