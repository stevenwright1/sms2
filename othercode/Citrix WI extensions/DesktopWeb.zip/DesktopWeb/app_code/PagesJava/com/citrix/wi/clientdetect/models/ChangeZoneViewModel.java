/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class ChangeZoneViewModel extends WizardViewModel {

    public String trustedZoneTextKey = null;
    public String siteURL = null;
    public String urlSiteAddedLink = null;
    public String urlCancelLink = null;
    public String securityMessageKey = null;
}
