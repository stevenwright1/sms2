// messages.js
// Copyright (c) 2001 - 2010 Citrix Systems, Inc. All Rights Reserved.

function onLoadLayout() {
  return;
}