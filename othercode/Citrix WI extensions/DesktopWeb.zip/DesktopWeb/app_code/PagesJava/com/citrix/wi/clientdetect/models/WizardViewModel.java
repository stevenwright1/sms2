/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class WizardViewModel extends ViewModel {

    public boolean showReturnToClientSelectionLink = false;
    public boolean showSkipLink = false;
    public boolean showLogoutLink = false;

}
