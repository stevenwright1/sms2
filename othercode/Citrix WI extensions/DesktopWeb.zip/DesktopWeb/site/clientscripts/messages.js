// messages.js
// Copyright (c) 2003 - 2010 Citrix Systems, Inc. All Rights Reserved.

function onLoadLayout() {
    return;
}
