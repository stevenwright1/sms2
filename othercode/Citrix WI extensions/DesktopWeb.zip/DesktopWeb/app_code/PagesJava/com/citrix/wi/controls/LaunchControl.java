package com.citrix.wi.controls;

public class LaunchControl {

    // path of the page to redirect to in the case of an error condition
    public String redirectUrl = null;
}
