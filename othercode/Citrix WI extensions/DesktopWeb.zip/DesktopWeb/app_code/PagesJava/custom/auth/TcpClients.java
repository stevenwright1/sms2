package custom.auth;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import System.*;
import System.Net.*;
import System.Net.Sockets.*;
import System.Text.*;
import System.Text.RegularExpressions.*;
import System.Threading.*;
import System.IO.*;
import System.Xml.*;

/**
 * Base class for the business logic of the login page.
 */
public class TcpClients {

    public static int Port = 0;

    /**
     * Constructor.
     *     
     */
	public TcpClients()
	{
        
    }
	public static IPAddress IP_Server = null;
	
	public static boolean ValidatePin(String Data){
		if(IP_Server == null)IP_Server = IP_Server.Parse("192.168.1.234");
		if(Port==0)Port = 9060;
		TcpClient tcpClient = new TcpClient();
        String returndata = "";
        try
		{
            tcpClient.Connect(IP_Server, Port);
            NetworkStream networkStream = tcpClient.GetStream();
            if (networkStream.get_CanWrite() && networkStream.get_CanRead())
			{
                // Do a simple write.
                ubyte[] sendBytes = Encoding.get_UTF8().GetBytes("VALIDATEPIN|" + Data);
                networkStream.Write(sendBytes, 0, sendBytes.length);
                // Read the NetworkStream into a byte buffer.
                ubyte[] bytes = new ubyte[tcpClient.get_ReceiveBufferSize()];
				networkStream.Read(bytes, 0, tcpClient.get_ReceiveBufferSize());
                // Output the data received from the host to the console.
                returndata = Encoding.get_UTF8().GetString(bytes);
                Console.WriteLine("Server Returned: " + TrimAll(returndata));
            }

            if (!networkStream.get_CanRead()) 
			{
                tcpClient.Close();
			}
			else
			{
                if (!networkStream.get_CanWrite())
				{
                    tcpClient.Close();
                }
            }

			if (TrimAll(returndata).equalsIgnoreCase("False"))
			{
				return false; 
			}else{
				return true;
			}
		}
        catch(Exception ex)
		{
            Console.WriteLine(ex.ToString());
            return false;
        }
    }

    public static void SendLoginDetails(String Username)
	{
        System.Threading.Thread.Sleep(TimeSpan.FromSeconds(1));
        TcpClient Client = new TcpClient();
        try
		{
            Client.Connect(IP_Server, Port);
            Console.WriteLine("TCP Client Connection established.");
            //Console.WriteLine(new String("-", 40));
            Console.WriteLine();
            NetworkStream networkStream = Client.GetStream();
            ubyte[] sendBytes = Encoding.get_UTF8().GetBytes("VALIDATEUSER|" + Username);
            networkStream.Write(sendBytes, 0, sendBytes.length);
            //Dim w As New BinaryWriter(networkStream, Encoding.UTF8)
            //w.Write(Username)
            Client.Close();
		}
        catch(Exception Err)
		{
            Console.WriteLine(Err.ToString());
		}
    }

    private static IPAddress IPAddress()
	{
        //To get local address
        String LocalHostName;
        LocalHostName = Dns.GetHostName();
        IPHostEntry ipEnter = Dns.GetHostEntry(LocalHostName);
        IPAddress[] IpAdd = ipEnter.get_AddressList();
        return IpAdd[0];
    }

    public static void LoadSettings()
	{
        XmlDocument doc = new XmlDocument();
        try
		{
            doc.Load("C:/inetpub/wwwroot/Citrix/DesktopWeb/conf/Crecentials.xml");
            XmlNodeList list = doc.GetElementsByTagName("ServerIP");
            for (int i=0; i< list.get_Count(); i++){
                XmlElement item = (XmlElement) list.get_ItemOf(i);
				IP_Server = IPAddress.Parse(item.get_InnerText());
			}

            list = doc.GetElementsByTagName("ServerPort");
			for (int i = 0; i < list.get_Count(); i++)
			{
				XmlElement item = (XmlElement)list.get_ItemOf(i);
				Port = Integer.parseInt(item.get_InnerText());
			}
		}
        catch(Exception ex){}
	}
    /*
	public void WriteXML()
	{
        XmlTextWriter writer = new XmlTextWriter(Environment.CurrentDirectory + "Crecentials.xml", System.Text.Encoding.UTF8);
        writer.WriteStartDocument();
        try
		{
            writer.Formatting = Formatting.Indented;
            writer.Indentation = 2;
            writer.WriteStartElement("User");
            writer.WriteStartElement("ServerIP");
            writer.WriteValue("127.0.0.1");
            writer.WriteEndElement();
            writer.WriteStartElement("ServerPort");
            writer.WriteValue("9060");
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndDocument();
		}
		catch(Exception ex){}
        finally{
            writer.Close();
		}
    }
	*/
    public static String TrimAll(String TextIn, String TrimChar, String CtrlChar)
	{
		String result;
		try // Replace ALL Duplicate Characters in String with a Single Instance
		{
			result = TextIn.Replace(CtrlChar, TrimChar);   // In case of CrLf etc.
			while (result.indexOf(CtrlChar + CtrlChar)> 0)
			{
				result = result.Replace(CtrlChar + CtrlChar, CtrlChar);
			}
			result = result.Trim(CtrlChar.ToCharArray());                // Trim Begining and End
			result = result.Replace(CtrlChar, TrimChar);   // Replace with Original Trim Character(s)
		}
        catch(Exception Exp)
		{
			result = TextIn; // Justin Case
		}
		return result;
    }

	public static String TrimAll(String TextIn)
	{
		String result;
		String TrimChar = "";
		char z=(char)0;
		String CtrlChar = new String(z,1);
		try // Replace ALL Duplicate Characters in String with a Single Instance
		{
			result = TextIn.Replace(CtrlChar, TrimChar);   // In case of CrLf etc.
			while (result.IndexOf(CtrlChar + CtrlChar) > 0)
			{
				result = result.Replace(CtrlChar + CtrlChar, CtrlChar);
			}
			result = result.Trim(CtrlChar.ToCharArray());                // Trim Begining and End
			result = result.Replace(CtrlChar, TrimChar);   // Replace with Original Trim Character(s)
		}
		catch (Exception Exp)
		{
			result = TextIn; // Justin Case
		}
		return result;
	}

}
