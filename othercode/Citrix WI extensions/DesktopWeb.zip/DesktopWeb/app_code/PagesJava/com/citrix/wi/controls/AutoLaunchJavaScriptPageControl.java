package com.citrix.wi.controls;

public class AutoLaunchJavaScriptPageControl {
    public String reconnectJavaScript = "";
    public String autoLaunchJavaScript = "";

}
