/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class ViewModel {
    public boolean transientPage = false;
    public String pageTitle = null;
}
