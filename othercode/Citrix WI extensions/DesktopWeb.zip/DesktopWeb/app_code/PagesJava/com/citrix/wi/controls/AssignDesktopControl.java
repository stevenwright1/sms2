/*
 * Copyright (c) 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.controls;

public class AssignDesktopControl {
    public String markup = "";
    public String redirectUrl = "";
    public String feedbackMessage = "";
    public boolean autoLaunch = true;
}
