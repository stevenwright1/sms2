/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class JavaNotAvailableViewModel extends WizardViewModel{

    public boolean showContinueText = false;
    public String urlCancelLink = null;

}
