/*
 * Copyright (c) 2007 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.controls;

/**
 * Maintains presentation state for the password expiry warning page control.
 */
public class PasswordExpiryWarnPageControl {

    public String expiryMessage = "";

}
