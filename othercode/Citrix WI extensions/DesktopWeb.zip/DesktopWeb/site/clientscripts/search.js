<%
// search.js
// Copyright (c) 2001 - 2010 Citrix Systems, Inc. All Rights Reserved.
// Web Interface 5.4.0.0
%>

function onLoadLayout()
{
    maintainAccessibility("SearchButton", true);
    setupSearchBox();
}
