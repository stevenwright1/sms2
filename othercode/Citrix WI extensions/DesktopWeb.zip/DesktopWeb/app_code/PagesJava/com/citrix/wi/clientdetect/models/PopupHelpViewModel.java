/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class PopupHelpViewModel extends WizardViewModel {

    public String allowPopupsTextKey = null;
    public String urlCancelLink = null;

}
