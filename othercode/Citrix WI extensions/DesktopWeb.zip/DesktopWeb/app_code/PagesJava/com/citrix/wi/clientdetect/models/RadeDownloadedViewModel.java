/*
 * Copyright (c) 2005 - 2010 Citrix Systems, Inc.  All Rights Reserved.
 */
package com.citrix.wi.clientdetect.models;

public class RadeDownloadedViewModel extends WizardViewModel {

    public String nextPage = null;
    public String skipWizardTextKey = null;
    public String skipWizardTooltipKey = null;

}
